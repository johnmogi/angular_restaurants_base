import { Component, OnInit } from '@angular/core';
import { store } from 'src/app/redux/store';
import { ActionType } from 'src/app/redux/action-type';
import { RestModel } from 'src/app/models/restos';
import { RestsService } from 'src/app/services/rests.service';

@Component({
  selector: 'app-restaurants',
  templateUrl: './restaurants.component.html',
  styleUrls: ['./restaurants.component.scss'],
})
export class RestaurantsComponent implements OnInit {
  public rests: RestModel[];

  constructor(private restsService: RestsService) {}

  async ngOnInit() {
    store.subscribe(() => {
      this.rests = store.getState().rests;
    });
    if (store.getState().rests.length === 0) {
      try {
        setTimeout(async () => {
          const rests = await this.restsService.GetAllRestos();
          const action = { type: ActionType.GetAllRests, payload: rests };
          store.dispatch(action);
        }, 3000);
      } catch (err) {
        alert('Error: ' + err.message);
      }
    } else {
      this.rests = store.getState().rests;
    }
  }
}
