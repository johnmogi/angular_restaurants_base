import { Injectable } from '@angular/core';
import { RestModel } from '../models/restos';
// global.config = require("../../../../server/config");

@Injectable({
  providedIn: 'root'
})
export class RestsService {

  constructor() { }
  public GetAllRestos(): Promise<RestModel[]> {
    return new Promise<RestModel[]>((resolve, reject) => {
        fetch(`http://localhost:3001/api/restaurants`)
            .then(response => response.json())
            .then(rests => resolve(rests))
            .catch(err => reject(err));
    });
  }
}
