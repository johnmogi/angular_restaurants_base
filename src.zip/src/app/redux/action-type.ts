export enum ActionType {
  GetAllRests,
  UpdateRest,
  DeleteRest,
  GetAllRevs,
  UpdateRev,
  DeleteRev,
  Login,
  Register,
  Logout,
}
