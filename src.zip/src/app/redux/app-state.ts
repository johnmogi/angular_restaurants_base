import { RestModel } from '../models/restos';
import { RevModel } from '../models/Reviews';
import { UserModel } from '../models/user';
export class AppState {
  public rests: RestModel[];
  public revs: RevModel[];
  public user: UserModel[];
  public constructor() {
    this.rests = [];
    this.revs = [];
    this.user = [];
  }
}
