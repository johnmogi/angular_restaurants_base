import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/pages/home/home.component';
import { RestaurantsComponent } from './components/pages/restaurants/restaurants.component';
import { LoginComponent } from './components/pages/auth/login/login.component';


const routes: Routes = [
  { path: "home", component: HomeComponent },
  { path: "restaurants", component: RestaurantsComponent },
  // { path: "products/new", component: InsertComponent },
  // { path: "products/:prodID", component: DetailsComponent },
  // { path: "about", component: AboutComponent },
   { path: "login", component: LoginComponent },

  // { path: "admin", loadChildren: "./admin/admin.module#AdminModule" }, // Lazy Loading
  // { path: "admin", loadChildren: () => import("./admin/admin.module").then(m => m.AdminModule) }, // Lazy Loading
  // { path: "", redirectTo: "/home", pathMatch: "full" }, // full = exact
  // { path: "**", component: PageNotFoundComponent }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
