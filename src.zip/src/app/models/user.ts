export class UserModel {
    public constructor(
        public userID?: number,
        public userName?: string,
        public password?: string,
        public role?: string
        ) {
        }
}
