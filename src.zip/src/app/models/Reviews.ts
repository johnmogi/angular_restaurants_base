export class RevModel {
    public constructor(
        public reviewID?: number,
        public restID?: number,
        public visitDate?: string,
        public visitorName?: string,
        public review?: string
        ) {
        }
}
